export * from "../wasm-pack/web/wasm_transformer";
export declare const wasmTransformerInit: (passedWasmTransformerUrl: string) => Promise<void>;
export default wasmTransformerInit;
