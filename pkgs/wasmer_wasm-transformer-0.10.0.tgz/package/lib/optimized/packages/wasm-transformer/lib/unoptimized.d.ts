export declare const lowerI64Imports: (wasmBinary: Uint8Array) => Promise<Uint8Array>;
export declare const version: () => Promise<string>;
