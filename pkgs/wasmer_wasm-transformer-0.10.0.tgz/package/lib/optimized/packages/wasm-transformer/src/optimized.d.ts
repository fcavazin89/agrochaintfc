export declare const wasmTransformerInit: (passedWasmTransformerUrl: string) => Promise<void>;
export declare const lowerI64Imports: (wasmBinary: Uint8Array) => Uint8Array;
export declare const version: () => string;
export default wasmTransformerInit;
